import React, { useState, useEffect, useRef } from "react";
import {
    Button,
    Text,
    Input,
    Dropdown,
    Option,
    Switch,
    DataGrid,
    DataGridHeader,
    DataGridBody,
    DataGridRow,
    DataGridCell,
    DataGridHeaderCell,
    TableCellLayout,
    ProgressBar,
    MessageBar,
    MessageBarBody,
    MessageBarTitle,
    MessageBarActions,
    makeStyles,
    mergeClasses,
    tokens,
} from "@fluentui/react-components";
import { DatePicker } from "@fluentui/react-datepicker-compat";
import {
    AddRegular,
    EditRegular,
    DeleteRegular,
    SaveRegular,
    SaveArrowRightRegular,
    DismissRegular,
    ArrowClockwiseRegular,
    PersonRegular,
    InfoRegular,
} from "@fluentui/react-icons";

// --- Localization Setup ---
const langMap: Record<number, { code: string; name: string; isRtl: boolean }> = {
    1033: { code: "en-US", name: "English (United States)", isRtl: false },
};

const translations: Record<string, Record<string, string>> = {
    "en-US": {
        pageTitle: "Referral Request Management",
        save: "Save",
        saveAndClose: "Save & Close",
        cancel: "Cancel",
        refresh: "Refresh",
        newReferralItem: "New Referral Item",
        add: "Add",
        edit: "Edit",
        delete: "Delete",
        close: "Close",
        requiredField: "This field is required.",
        loading: "Loading...",
        saving: "Saving...",
        saveSuccess: "Referral Request saved successfully.",
        saveError: "Error saving Referral Request.",
        addItemSuccess: "Referral Item added successfully.",
        addItemError: "Error adding Referral Item.",
        updateItemSuccess: "Referral Item updated successfully.",
        updateItemError: "Error updating Referral Item.",
        deleteItemSuccess: "Referral Item deleted successfully.",
        deleteItemError: "Error deleting Referral Item.",
        headerSection: "Header",
        generalInfoSection: "General Information",
        businessInfoSection: "Business Information",
        auditInfoSection: "Audit Information",
        referralItemsSection: "Referral Items",
        createdOn: "Created On",
        modifiedOn: "Last Modified",
        owner: "Owner",
        status: "Status",
        statusReason: "Status Reason",
        state: "State",
        actions: "Actions",
        noItems: "No Referral Items found.",
        confirmDelete: "Are you sure you want to delete this item?",
        yes: "Yes",
        no: "No",
        autosaving: "Autosaving...",
        autosaveSuccess: "Autosave successful.",
        autosaveError: "Autosave failed.",
        validationError: "Please fill all required fields.",
        // Add more as needed
    },
};

// --- Styles ---
const useStyles = makeStyles({
    root: {
        flexGrow: 1,
        alignSelf: "stretch",
        width: "100%",
        height: "100%",
        boxSizing: "border-box",
        display: "flex",
        flexDirection: "column",
        backgroundColor: tokens.colorNeutralBackground1,
        padding: tokens.spacingHorizontalL,
        overflow: "hidden",
    },
    header: {
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: tokens.spacingVerticalL,
        paddingBottom: tokens.spacingVerticalS,
        borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    },
    section: {
        backgroundColor: tokens.colorNeutralBackground2,
        borderRadius: tokens.borderRadiusLarge,
        boxShadow: tokens.shadow4,
        padding: tokens.spacingHorizontalL,
        marginBottom: tokens.spacingVerticalL,
        boxSizing: "border-box",
        width: "100%",
    },
    sectionHeader: {
        fontWeight: tokens.fontWeightSemibold,
        fontSize: tokens.fontSizeBase500,
        marginBottom: tokens.spacingVerticalS,
        color: tokens.colorBrandForeground1,
    },
    formRow: {
        display: "flex",
        flexWrap: "wrap",
        gap: tokens.spacingHorizontalL,
        marginBottom: tokens.spacingVerticalS,
    },
    formField: {
        flex: "1 1 220px",
        minWidth: "180px",
        marginBottom: tokens.spacingVerticalS,
        display: "flex",
        flexDirection: "column",
    },
    label: {
        fontWeight: tokens.fontWeightSemibold,
        marginBottom: tokens.spacingVerticalXS,
    },
    gridContainer: {
        marginTop: tokens.spacingVerticalM,
        backgroundColor: tokens.colorNeutralBackground1,
        borderRadius: tokens.borderRadiusMedium,
        boxShadow: tokens.shadow2,
        padding: tokens.spacingHorizontalM,
        maxHeight: "320px",
        overflow: "auto",
        width: "100%",
    },
    gridHeader: {
        fontWeight: tokens.fontWeightSemibold,
        fontSize: tokens.fontSizeBase400,
        marginBottom: tokens.spacingVerticalS,
    },
    navBar: {
        display: "flex",
        flexDirection: "row",
        gap: tokens.spacingHorizontalM,
        marginBottom: tokens.spacingVerticalM,
    },
    messageBar: {
        marginBottom: tokens.spacingVerticalM,
    },
    spinner: {
        margin: "auto",
        marginTop: tokens.spacingVerticalXXL,
    },
    dialogOverlay: {
        position: "fixed",
        top: 0,
        left: 0,
        width: "100vw",
        height: "100vh",
        backgroundColor: "rgba(0,0,0,0.2)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    },
    dialog: {
        backgroundColor: tokens.colorNeutralBackground1,
        borderRadius: tokens.borderRadiusLarge,
        boxShadow: tokens.shadow8,
        padding: tokens.spacingHorizontalXXL,
        minWidth: "350px",
        maxWidth: "90vw",
        maxHeight: "90vh",
        overflowY: "auto",
        display: "flex",
        flexDirection: "column",
        gap: tokens.spacingVerticalM,
    },
    dialogActions: {
        display: "flex",
        flexDirection: "row",
        gap: tokens.spacingHorizontalM,
        justifyContent: "flex-end",
        marginTop: tokens.spacingVerticalM,
    },
    auditField: {
        marginBottom: tokens.spacingVerticalXS,
    },
    required: {
        color: tokens.colorStatusDangerForeground1,
        marginLeft: tokens.spacingHorizontalXS,
    },
    errorText: {
        color: tokens.colorStatusDangerForeground1,
        fontSize: tokens.fontSizeBase300,
        marginTop: tokens.spacingVerticalXS,
    },
    successText: {
        color: tokens.colorStatusSuccessForeground1,
        fontSize: tokens.fontSizeBase300,
        marginTop: tokens.spacingVerticalXS,
    },
});

// --- Utility Functions ---
function groupFields(fields: any[]): { general: any[]; business: any[] } {
    // Group fields by business logic or data type (stub: split by name for demo)
    const general: any[] = [];
    const business: any[] = [];
    fields.forEach((f) => {
        if (f.logicalName?.toLowerCase().includes("business")) business.push(f);
        else general.push(f);
    });
    return { general, business };
}

function getFieldLabel(field: any) {
    return field.displayName || field.logicalName || "";
}

function isRequiredField(field: any) {
    return field.required === true;
}

function isLookupField(field: any) {
    return field.type === "Lookup";
}

function isDateField(field: any) {
    return field.type === "DateTime";
}

function isBooleanField(field: any) {
    return field.type === "Boolean";
}

function isNumberField(field: any) {
    return field.type === "Decimal" || field.type === "Integer" || field.type === "Money";
}

function isOptionSetField(field: any) {
    return field.type === "OptionSet";
}

function isMultiLineTextField(field: any) {
    return field.type === "MultiLineText";
}

function isRichTextField(field: any) {
    return field.type === "RichText";
}

// --- Main Component ---
const GeneratedComponent = (props: any) => {
    // --- Localization ---
    const language = React.useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
            1033;
        return langMap[uiLanguageId]?.code || "en-US";
    }, []);
    const isRTL = React.useMemo(() => {
        const uiLanguageId =
            (typeof Xrm !== "undefined" &&
                Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
            1033;
        return langMap[uiLanguageId]?.isRtl || false;
    }, []);
    const t = (key: string): string =>
        translations[language]?.[key] || translations["en-US"]?.[key] || key;

    // --- User Settings for Formatting ---
    const [userSettings, setUserSettings] = useState<any>(null);
    useEffect(() => {
        const fetchUserSettings = async () => {
            const currentUserId =
                (typeof Xrm !== "undefined" &&
                    Xrm.Utility?.getGlobalContext()?.userSettings?.userId)
                    ?.replace("{", "")
                    .replace("}", "");
            if (!currentUserId || !props.dataApi) return;
            const settings = await props.dataApi.retrieveRow("usersettings", {
                id: currentUserId,
                select: [
                    "uilanguageid",
                    "localeid",
                    "decimalsymbol",
                    "numberseparator",
                    "currencysymbol",
                    "dateformatstring",
                    "dateseparator",
                ],
            });
            setUserSettings(settings);
        };
        fetchUserSettings();
    }, [props.dataApi]);

    // --- Formatting Helpers ---
    const formatDate = (date: Date | string | number | null | undefined): string => {
        if (date === null || date === undefined || date === "") return "";
        const d = date instanceof Date ? date : new Date(date);
        if (isNaN(d.getTime())) return "";
        if (!userSettings) return d.toLocaleDateString(language);
        const sep = userSettings.dateseparator || "/";
        const fmt = (userSettings.dateformatstring || "MM/dd/yyyy")
            .replace("yyyy", d.getFullYear().toString())
            .replace("MM", String(d.getMonth() + 1).padStart(2, "0"))
            .replace("dd", String(d.getDate()).padStart(2, "0"))
            .replace("/", sep)
            .replace("/", sep);
        return fmt;
    };
    const formatNumber = (value: number | string | null | undefined): string => {
        if (value === null || value === undefined || value === "") return "";
        const num = typeof value === "number" ? value : Number(value);
        if (isNaN(num)) return "";
        if (!userSettings) return new Intl.NumberFormat(language).format(num);
        const dec = userSettings.decimalsymbol || ".";
        const grp = userSettings.numberseparator || ",";
        const parts = num.toFixed(2).split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, grp);
        return parts.join(dec);
    };
    const formatCurrency = (value: number | string | null | undefined): string => {
        if (value === null || value === undefined || value === "") return "";
        const symbol = userSettings?.currencysymbol || "$";
        return `${symbol}${formatNumber(value)}`;
    };

    // --- Styles ---
    const styles = useStyles();

    // --- State ---
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [autosaving, setAutosaving] = useState(false);
    const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);
    const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
    const [fields, setFields] = useState<any[]>([]);
    const [systemFields, setSystemFields] = useState<any[]>([]);
    const [formData, setFormData] = useState<any>({});
    const [auditData, setAuditData] = useState<any>({});
    const [childItems, setChildItems] = useState<any[]>([]);
    const [childFields, setChildFields] = useState<any[]>([]);
    const [childLoading, setChildLoading] = useState(false);
    const [childDialogOpen, setChildDialogOpen] = useState(false);
    const [editingChild, setEditingChild] = useState<any | null>(null);
    const [childDialogData, setChildDialogData] = useState<any>({});
    const [childDialogErrors, setChildDialogErrors] = useState<Record<string, string>>({});
    const [refreshKey, setRefreshKey] = useState(0);

    // --- Fetch Table Schema and Data ---
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                // 1. Fetch Referral Request table schema
                // 2. Fetch current record data (if editing)
                // 3. Fetch system fields
                // 4. Fetch child Referral Item schema
                // 5. Fetch child items
                // [UxAgent] NOTE: Replace with actual schema/dataApi calls in real environment
                // For demo, use mocked schema and data
                const mockFields = [
                    { logicalName: "slcrm_title", displayName: "Title", type: "Text", required: true },
                    { logicalName: "slcrm_description", displayName: "Description", type: "MultiLineText", required: false },
                    { logicalName: "slcrm_priority", displayName: "Priority", type: "OptionSet", options: [{ value: 1, label: "Low" }, { value: 2, label: "Medium" }, { value: 3, label: "High" }], required: false },
                    { logicalName: "slcrm_referraldate", displayName: "Referral Date", type: "DateTime", required: true },
                    { logicalName: "slcrm_isurgent", displayName: "Is Urgent", type: "Boolean", required: false },
                    { logicalName: "slcrm_amount", displayName: "Amount", type: "Money", required: false },
                    { logicalName: "slcrm_businesscategory", displayName: "Business Category", type: "Text", required: false },
                    { logicalName: "slcrm_businessnotes", displayName: "Business Notes", type: "MultiLineText", required: false },
                    // Add more as needed
                ];
                // Remove "status" field and add "status reason" field
                const mockSystemFields = [
                    { logicalName: "createdon", displayName: t("createdOn"), type: "DateTime" },
                    { logicalName: "modifiedon", displayName: t("modifiedOn"), type: "DateTime" },
                    { logicalName: "ownerid", displayName: t("owner"), type: "Lookup" },
                    { logicalName: "statuscode", displayName: t("statusReason"), type: "OptionSet", options: [{ value: 1, label: "New" }, { value: 2, label: "In Progress" }, { value: 3, label: "Completed" }] },
                    { logicalName: "statecode", displayName: t("state"), type: "OptionSet", options: [{ value: 0, label: "Open" }, { value: 1, label: "Closed" }] },
                ];
                const mockFormData = {
                    slcrm_title: "",
                    slcrm_description: "",
                    slcrm_priority: 2,
                    slcrm_referraldate: "",
                    slcrm_isurgent: false,
                    slcrm_amount: "",
                    slcrm_businesscategory: "",
                    slcrm_businessnotes: "",
                    createdon: new Date(),
                    modifiedon: new Date(),
                    ownerid: "John Doe",
                    statuscode: 1,
                    statecode: 0,
                };
                const mockAuditData = {
                    createdon: new Date(),
                    modifiedon: new Date(),
                    ownerid: "John Doe",
                    statuscode: 1,
                    statecode: 0,
                };
                const mockChildFields = [
                    { logicalName: "slcrm_itemname", displayName: "Item Name", type: "Text", required: true },
                    { logicalName: "slcrm_itemstatus", displayName: "Status", type: "OptionSet", options: [{ value: 1, label: "Pending" }, { value: 2, label: "Completed" }], required: true },
                    { logicalName: "slcrm_itemowner", displayName: "Owner", type: "Text", required: false },
                    { logicalName: "createdon", displayName: t("createdOn"), type: "DateTime" },
                ];
                const mockChildItems = [
                    {
                        id: "1",
                        slcrm_itemname: "Initial Review",
                        slcrm_itemstatus: 1,
                        slcrm_itemowner: "Jane Smith",
                        createdon: new Date(),
                    },
                    {
                        id: "2",
                        slcrm_itemname: "Follow Up",
                        slcrm_itemstatus: 2,
                        slcrm_itemowner: "John Doe",
                        createdon: new Date(),
                    },
                ];
                setFields(mockFields);
                setSystemFields(mockSystemFields);
                setFormData(mockFormData);
                setAuditData(mockAuditData);
                setChildFields(mockChildFields);
                setChildItems(mockChildItems);
            } catch (err) {
                setNotification({ type: "error", message: t("saveError") });
            }
            setLoading(false);
        };
        fetchData();
        // eslint-disable-next-line
    }, [refreshKey]);

    // --- Autosave (simulate) ---
    useEffect(() => {
        if (!formData || loading) return;
        const timeout = setTimeout(() => {
            setAutosaving(true);
            // Simulate autosave
            setTimeout(() => {
                setAutosaving(false);
                setNotification({ type: "success", message: t("autosaveSuccess") });
            }, 800);
        }, 4000);
        return () => clearTimeout(timeout);
        // eslint-disable-next-line
    }, [formData]);

    // --- Validation ---
    const validateForm = () => {
        const errors: Record<string, string> = {};
        fields.forEach((field) => {
            if (isRequiredField(field) && !formData[field.logicalName]) {
                errors[field.logicalName] = t("requiredField");
            }
        });
        setValidationErrors(errors);
        return Object.keys(errors).length === 0;
    };

    // --- Handlers ---
    const handleInputChange = (field: any, value: any) => {
        setFormData((prev: any) => ({ ...prev, [field.logicalName]: value }));
        setValidationErrors((prev) => ({ ...prev, [field.logicalName]: undefined }));
    };

    const handleSave = async (closeAfter?: boolean) => {
        if (!validateForm()) {
            setNotification({ type: "error", message: t("validationError") });
            return;
        }
        setSaving(true);
        try {
            // [Power Fx] Patch(ReferralRequest, formData)
            // await props.dataApi.updateRow("slcrm_referralrequest", recordId, formData);
            setTimeout(() => {
                setSaving(false);
                setNotification({ type: "success", message: t("saveSuccess") });
                if (closeAfter) {
                    // [Power Fx] Navigate(PreviousScreen)
                }
            }, 1000);
        } catch (err) {
            setSaving(false);
            setNotification({ type: "error", message: t("saveError") });
        }
    };

    const handleCancel = () => {
        // [Power Fx] Navigate(PreviousScreen)
    };

    const handleRefresh = () => {
        setRefreshKey((k) => k + 1);
    };

    // --- Child Referral Items ---
    const handleAddChild = () => {
        setEditingChild(null);
        setChildDialogData({});
        setChildDialogErrors({});
        setChildDialogOpen(true);
    };

    const handleEditChild = (item: any) => {
        setEditingChild(item);
        setChildDialogData(item);
        setChildDialogErrors({});
        setChildDialogOpen(true);
    };

    const handleDeleteChild = (item: any) => {
        if (window.confirm(t("confirmDelete"))) {
            setChildItems((prev) => prev.filter((i) => i.id !== item.id));
            setNotification({ type: "success", message: t("deleteItemSuccess") });
        }
    };

    const handleChildDialogChange = (field: any, value: any) => {
        setChildDialogData((prev: any) => ({ ...prev, [field.logicalName]: value }));
        setChildDialogErrors((prev) => ({ ...prev, [field.logicalName]: undefined }));
    };

    const validateChildDialog = () => {
        const errors: Record<string, string> = {};
        childFields.forEach((field) => {
            if (isRequiredField(field) && !childDialogData[field.logicalName]) {
                errors[field.logicalName] = t("requiredField");
            }
        });
        setChildDialogErrors(errors);
        return Object.keys(errors).length === 0;
    };

    const handleChildDialogSave = () => {
        if (!validateChildDialog()) return;
        if (editingChild) {
            // [Power Fx] Patch(ReferralItem, childDialogData)
            setChildItems((prev) =>
                prev.map((i) => (i.id === editingChild.id ? { ...childDialogData, id: editingChild.id } : i))
            );
            setNotification({ type: "success", message: t("updateItemSuccess") });
        } else {
            // [Power Fx] Patch(ReferralItem, { ...childDialogData, parent: formData.id })
            setChildItems((prev) => [
                ...prev,
                { ...childDialogData, id: Math.random().toString(36).substr(2, 9) },
            ]);
            setNotification({ type: "success", message: t("addItemSuccess") });
        }
        setChildDialogOpen(false);
    };

    // --- Field Grouping ---
    const { general, business } = groupFields(fields);

    // --- Child Grid Columns ---
    const childColumns = childFields.map((field) => ({
        columnId: field.logicalName,
        renderHeaderCell: () => getFieldLabel(field),
        renderCell: (item: any) => {
            if (isDateField(field)) return <TableCellLayout>{formatDate(item[field.logicalName])}</TableCellLayout>;
            if (isOptionSetField(field)) {
                const opt = field.options?.find((o: any) => o.value === item[field.logicalName]);
                return <TableCellLayout>{opt ? opt.label : ""}</TableCellLayout>;
            }
            return <TableCellLayout>{item[field.logicalName]}</TableCellLayout>;
        },
    }));
    childColumns.push({
        columnId: "actions",
        renderHeaderCell: () => t("actions"),
        renderCell: (item: any) => (
            <div style={{ display: "flex", gap: 8 }}>
                <Button
                    icon={<EditRegular />}
                    size="small"
                    aria-label={t("edit")}
                    onClick={() => handleEditChild(item)}
                />
                <Button
                    icon={<DeleteRegular />}
                    size="small"
                    aria-label={t("delete")}
                    onClick={() => handleDeleteChild(item)}
                />
            </div>
        ),
    });

    // --- Render ---
    return (
        <div
            className={styles.root}
            dir={isRTL ? "rtl" : "ltr"}
            style={{ direction: isRTL ? "rtl" : "ltr" }}
        >
            {/* Page Header */}
            <div className={styles.header}>
                <Text as="h1" size={700} weight="semibold">
                    {t("pageTitle")}
                </Text>
                <div className={styles.navBar}>
                    <Button
                        appearance="primary"
                        icon={<SaveRegular />}
                        onClick={() => handleSave(false)}
                        disabled={saving || loading}
                    >
                        {t("save")}
                    </Button>
                    <Button
                        appearance="secondary"
                        icon={<SaveArrowRightRegular />}
                        onClick={() => handleSave(true)}
                        disabled={saving || loading}
                    >
                        {t("saveAndClose")}
                    </Button>
                    <Button
                        appearance="outline"
                        icon={<DismissRegular />}
                        onClick={handleCancel}
                        disabled={saving || loading}
                    >
                        {t("cancel")}
                    </Button>
                    <Button
                        appearance="subtle"
                        icon={<ArrowClockwiseRegular />}
                        onClick={handleRefresh}
                        disabled={saving || loading}
                    >
                        {t("refresh")}
                    </Button>
                    <Button
                        appearance="primary"
                        icon={<AddRegular />}
                        onClick={handleAddChild}
                        disabled={saving || loading}
                    >
                        {t("newReferralItem")}
                    </Button>
                </div>
            </div>

            {/* Notifications */}
            {notification && (
                <MessageBar
                    intent={notification.type === "success" ? "success" : "error"}
                    shape="rounded"
                    className={styles.messageBar}
                    actions={
                        <MessageBarActions>
                            <Button
                                appearance="subtle"
                                icon={<DismissRegular />}
                                onClick={() => setNotification(null)}
                                aria-label={t("close")}
                            />
                        </MessageBarActions>
                    }
                >
                    <MessageBarBody>
                        <MessageBarTitle>{notification.message}</MessageBarTitle>
                    </MessageBarBody>
                </MessageBar>
            )}
            {autosaving && (
                <MessageBar
                    intent="info"
                    shape="rounded"
                    className={styles.messageBar}
                >
                    <MessageBarBody>
                        <MessageBarTitle>{t("autosaving")}</MessageBarTitle>
                    </MessageBarBody>
                </MessageBar>
            )}

            {/* Loading */}
            {(loading || saving) && (
                <div style={{ width: "100%", display: "flex", justifyContent: "center" }}>
                    <ProgressBar thickness="large" shape="rounded" value={undefined} style={{ width: "40%" }} />
                </div>
            )}

            {/* Main Form Sections */}
            {!loading && (
                <>
                    {/* Header Section */}
                    <section className={styles.section} aria-labelledby="header-section">
                        <Text as="h2" className={styles.sectionHeader} id="header-section">
                            {t("headerSection")}
                        </Text>
                        <div className={styles.formRow}>
                            <div className={styles.formField}>
                                <Text className={styles.label}>{getFieldLabel(fields.find(f => f.logicalName === "slcrm_title") || { displayName: "Title" })}</Text>
                                <Input
                                    value={formData.slcrm_title || ""}
                                    onChange={(_, d) => handleInputChange({ logicalName: "slcrm_title" }, d.value)}
                                    required
                                    aria-required
                                    disabled={saving}
                                />
                                {validationErrors.slcrm_title && (
                                    <span className={styles.errorText}>{validationErrors.slcrm_title}</span>
                                )}
                            </div>
                            {/* Hide status field, show status reason field */}
                            <div className={styles.formField}>
                                <Text className={styles.label}>{t("statusReason")}</Text>
                                <Dropdown
                                    value={formData.statuscode}
                                    onOptionSelect={(_, d) => handleInputChange({ logicalName: "statuscode" }, d.optionValue)}
                                    disabled={saving}
                                >
                                    {(systemFields.find(f => f.logicalName === "statuscode")?.options || []).map((opt: any) => (
                                        <Option key={opt.value} value={opt.value}>{opt.label}</Option>
                                    ))}
                                </Dropdown>
                            </div>
                            <div className={styles.formField}>
                                <Text className={styles.label}>{t("owner")}</Text>
                                <Input value={formData.ownerid || ""} disabled />
                            </div>
                            <div className={styles.formField}>
                                <Text className={styles.label}>{t("createdOn")}</Text>
                                <Input value={formatDate(formData.createdon)} disabled />
                            </div>
                            <div className={styles.formField}>
                                <Text className={styles.label}>{t("modifiedOn")}</Text>
                                <Input value={formatDate(formData.modifiedon)} disabled />
                            </div>
                        </div>
                    </section>

                    {/* General Information Section */}
                    <section className={styles.section} aria-labelledby="general-info-section">
                        <Text as="h2" className={styles.sectionHeader} id="general-info-section">
                            {t("generalInfoSection")}
                        </Text>
                        <div className={styles.formRow}>
                            {general.map((field) => (
                                <div className={styles.formField} key={field.logicalName}>
                                    <Text className={styles.label}>
                                        {getFieldLabel(field)}
                                        {isRequiredField(field) && <span className={styles.required}>*</span>}
                                    </Text>
                                    {isOptionSetField(field) ? (
                                        <Dropdown
                                            value={formData[field.logicalName]}
                                            onOptionSelect={(_, d) => handleInputChange(field, d.optionValue)}
                                            disabled={saving}
                                        >
                                            {(field.options || []).map((opt: any) => (
                                                <Option key={opt.value} value={opt.value}>{opt.label}</Option>
                                            ))}
                                        </Dropdown>
                                    ) : isDateField(field) ? (
                                        <DatePicker
                                            value={formData[field.logicalName] ? new Date(formData[field.logicalName]) : undefined}
                                            onSelectDate={(date) => handleInputChange(field, date)}
                                            mountNode={document.body}
                                            disabled={saving}
                                        />
                                    ) : isBooleanField(field) ? (
                                        <Switch
                                            checked={!!formData[field.logicalName]}
                                            onChange={(_, d) => handleInputChange(field, d.checked)}
                                            disabled={saving}
                                        />
                                    ) : isNumberField(field) ? (
                                        <Input
                                            type="number"
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                        />
                                    ) : isMultiLineTextField(field) ? (
                                        <Input
                                            as="textarea"
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                            rows={3}
                                        />
                                    ) : (
                                        <Input
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                        />
                                    )}
                                    {validationErrors[field.logicalName] && (
                                        <span className={styles.errorText}>{validationErrors[field.logicalName]}</span>
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Business Information Section */}
                    <section className={styles.section} aria-labelledby="business-info-section">
                        <Text as="h2" className={styles.sectionHeader} id="business-info-section">
                            {t("businessInfoSection")}
                        </Text>
                        <div className={styles.formRow}>
                            {business.map((field) => (
                                <div className={styles.formField} key={field.logicalName}>
                                    <Text className={styles.label}>
                                        {getFieldLabel(field)}
                                        {isRequiredField(field) && <span className={styles.required}>*</span>}
                                    </Text>
                                    {isOptionSetField(field) ? (
                                        <Dropdown
                                            value={formData[field.logicalName]}
                                            onOptionSelect={(_, d) => handleInputChange(field, d.optionValue)}
                                            disabled={saving}
                                        >
                                            {(field.options || []).map((opt: any) => (
                                                <Option key={opt.value} value={opt.value}>{opt.label}</Option>
                                            ))}
                                        </Dropdown>
                                    ) : isDateField(field) ? (
                                        <DatePicker
                                            value={formData[field.logicalName] ? new Date(formData[field.logicalName]) : undefined}
                                            onSelectDate={(date) => handleInputChange(field, date)}
                                            mountNode={document.body}
                                            disabled={saving}
                                        />
                                    ) : isBooleanField(field) ? (
                                        <Switch
                                            checked={!!formData[field.logicalName]}
                                            onChange={(_, d) => handleInputChange(field, d.checked)}
                                            disabled={saving}
                                        />
                                    ) : isNumberField(field) ? (
                                        <Input
                                            type="number"
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                        />
                                    ) : isMultiLineTextField(field) ? (
                                        <Input
                                            as="textarea"
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                            rows={3}
                                        />
                                    ) : (
                                        <Input
                                            value={formData[field.logicalName] || ""}
                                            onChange={(_, d) => handleInputChange(field, d.value)}
                                            disabled={saving}
                                        />
                                    )}
                                    {validationErrors[field.logicalName] && (
                                        <span className={styles.errorText}>{validationErrors[field.logicalName]}</span>
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Audit Information Section */}
                    <section className={styles.section} aria-labelledby="audit-info-section">
                        <Text as="h2" className={styles.sectionHeader} id="audit-info-section">
                            {t("auditInfoSection")}
                        </Text>
                        <div className={styles.formRow}>
                            {systemFields
                                .filter(field => field.logicalName !== "status") // Hide status, show status reason
                                .map((field) => (
                                <div className={styles.formField} key={field.logicalName}>
                                    <Text className={styles.label}>{getFieldLabel(field)}</Text>
                                    {isOptionSetField(field) ? (
                                        <Dropdown
                                            value={auditData[field.logicalName]}
                                            disabled
                                        >
                                            {(field.options || []).map((opt: any) => (
                                                <Option key={opt.value} value={opt.value}>{opt.label}</Option>
                                            ))}
                                        </Dropdown>
                                    ) : (
                                        <Input
                                            value={
                                                isDateField(field)
                                                    ? formatDate(auditData[field.logicalName])
                                                    : auditData[field.logicalName]
                                            }
                                            disabled
                                        />
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Child Referral Items Section */}
                    <section className={styles.section} aria-labelledby="referral-items-section">
                        <Text as="h2" className={styles.sectionHeader} id="referral-items-section">
                            {t("referralItemsSection")}
                        </Text>
                        <div className={styles.gridContainer}>
                            <DataGrid
                                items={childItems}
                                columns={childColumns}
                                sortable
                                selectionMode="none"
                                getRowId={(item) => item.id}
                                focusMode="composite"
                                style={{ minWidth: 400 }}
                            >
                                <DataGridHeader>
                                    <DataGridRow>
                                        {childColumns.map((col, idx) => (
                                            <DataGridHeaderCell key={col.columnId || idx}>{col.renderHeaderCell()}</DataGridHeaderCell>
                                        ))}
                                    </DataGridRow>
                                </DataGridHeader>
                                <DataGridBody>
                                    {({ item }) => (
                                        <DataGridRow key={item.id}>
                                            {childColumns.map((col, idx) => (
                                                <DataGridCell key={col.columnId || idx}>{col.renderCell(item)}</DataGridCell>
                                            ))}
                                        </DataGridRow>
                                    )}
                                </DataGridBody>
                            </DataGrid>
                            {childItems.length === 0 && (
                                <Text size={300} style={{ marginTop: 12 }}>
                                    {t("noItems")}
                                </Text>
                            )}
                        </div>
                    </section>
                </>
            )}

            {/* Child Referral Item Dialog */}
            {childDialogOpen && (
                <div className={styles.dialogOverlay}>
                    <div className={styles.dialog} role="dialog" aria-modal="true">
                        <Text as="h3" size={500} weight="semibold">
                            {editingChild ? t("edit") : t("add")}
                        </Text>
                        {childFields.map((field) => (
                            <div className={styles.formField} key={field.logicalName}>
                                <Text className={styles.label}>
                                    {getFieldLabel(field)}
                                    {isRequiredField(field) && <span className={styles.required}>*</span>}
                                </Text>
                                {isOptionSetField(field) ? (
                                    <Dropdown
                                        value={childDialogData[field.logicalName]}
                                        onOptionSelect={(_, d) => handleChildDialogChange(field, d.optionValue)}
                                    >
                                        {(field.options || []).map((opt: any) => (
                                            <Option key={opt.value} value={opt.value}>{opt.label}</Option>
                                        ))}
                                    </Dropdown>
                                ) : isDateField(field) ? (
                                    <DatePicker
                                        value={childDialogData[field.logicalName] ? new Date(childDialogData[field.logicalName]) : undefined}
                                        onSelectDate={(date) => handleChildDialogChange(field, date)}
                                        mountNode={document.body}
                                    />
                                ) : isBooleanField(field) ? (
                                    <Switch
                                        checked={!!childDialogData[field.logicalName]}
                                        onChange={(_, d) => handleChildDialogChange(field, d.checked)}
                                    />
                                ) : isNumberField(field) ? (
                                    <Input
                                        type="number"
                                        value={childDialogData[field.logicalName] || ""}
                                        onChange={(_, d) => handleChildDialogChange(field, d.value)}
                                    />
                                ) : isMultiLineTextField(field) ? (
                                    <Input
                                        as="textarea"
                                        value={childDialogData[field.logicalName] || ""}
                                        onChange={(_, d) => handleChildDialogChange(field, d.value)}
                                        rows={3}
                                    />
                                ) : (
                                    <Input
                                        value={childDialogData[field.logicalName] || ""}
                                        onChange={(_, d) => handleChildDialogChange(field, d.value)}
                                    />
                                )}
                                {childDialogErrors[field.logicalName] && (
                                    <span className={styles.errorText}>{childDialogErrors[field.logicalName]}</span>
                                )}
                            </div>
                        ))}
                        <div className={styles.dialogActions}>
                            <Button appearance="primary" icon={<SaveRegular />} onClick={handleChildDialogSave}>
                                {t("save")}
                            </Button>
                            <Button appearance="outline" icon={<DismissRegular />} onClick={() => setChildDialogOpen(false)}>
                                {t("cancel")}
                            </Button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default GeneratedComponent;