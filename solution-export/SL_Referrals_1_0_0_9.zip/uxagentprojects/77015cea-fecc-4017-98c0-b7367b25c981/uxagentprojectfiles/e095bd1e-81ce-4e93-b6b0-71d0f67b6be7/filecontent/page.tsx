import React, {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback,
} from "react";
import {
  Button,
  Text,
  Input,
  Combobox,
  Option,
  DataGrid,
  DataGridHeader,
  DataGridBody,
  DataGridRow,
  DataGridCell,
  DataGridHeaderCell,
  TableCellLayout,
  createTableColumn,
  ProgressBar,
  Tag,
  makeStyles,
  tokens,
} from "@fluentui/react-components";
import {
  ArrowLeftRegular,
  SaveRegular,
  DismissRegular,
  AddRegular,
  EditRegular,
  DeleteRegular,
  InfoRegular,
  PersonRegular,
  ClockRegular,
  DocumentDataRegular,
  ShareRegular,
} from "@fluentui/react-icons";
import { DatePicker } from "@fluentui/react-datepicker-compat";

// --- Localization Setup ---
const langMap: Record<
  number,
  { code: string; name: string; isRtl: boolean }
> = {
  1033: { code: "en-US", name: "English (United States)", isRtl: false },
};

const translations: Record<string, Record<string, string>> = {
  "en-US": {
    createReferral: "Create Referral",
    newReferral: "New Referral",
    referralNumber: "Referral Number",
    status: "Status",
    saveDraft: "Save Draft",
    cancel: "Cancel",
    saveAndContinue: "Save and Continue",
    back: "Back",
    referralDetails: "Referral Details",
    referralItems: "Referral Items",
    reviewAndSubmit: "Review and Submit",
    addReferralItem: "Add Referral Item",
    edit: "Edit",
    remove: "Remove",
    noReferralItems: "No referral items have been added. Add at least one item before submitting.",
    submitReferral: "Submit Referral",
    validationSummary: "Validation Summary",
    loading: "Loading...",
    error: "Error",
    required: "Required",
    opportunity: "Opportunity",
    product: "Product",
    customer: "Customer/Insured",
    primaryUnderwriter: "Primary Underwriter",
    brokerAccount: "Broker Account",
    brokerContact: "Broker Contact",
    transactionType: "Transaction Type",
    policyType: "Policy Type",
    countryOfReferral: "Country of Referral",
    inceptionDate: "Inception/Effective Date",
    priority: "Priority",
    businessDescription: "Business/Risk Description",
    transactionCurrency: "Transaction Currency",
    premium100: "100% Premium",
    intactShare: "Intact Share %",
    intactPremium: "Intact Premium",
    intactNWP: "Intact NWP",
    ukPremium: "UK Premium",
    maxPolicyLimit: "Maximum Policy Limit/EML",
    emlCurrency: "EML Currency",
    emlAmount: "EML Amount",
    intactExposure: "Intact Exposure",
    externalQuoteNumber: "External Quote Number",
    externalQuoteUrl: "External Quote URL",
    policyNumber: "Policy Number",
    uwFolderUrl: "UW Folder URL",
    ratingToolUrl: "Rating Tool URL",
    referralReason: "Referral Reason",
    coverSection: "Cover/Section",
    itemSummary: "Item Summary",
    referralDetailsLabel: "Referral Details",
    underwriterRationale: "Underwriter Rationale",
    requestedDecision: "Requested Decision/Exception",
    supportingDocUrl: "Supporting Document URL",
    evidenceNotes: "Evidence Notes",
    requiredAuthorityLevel: "Required Authority Level",
    requiredRank: "Required Rank",
    selectedUnderwritingAuthority: "Selected Underwriting Authority",
    assignedApprover: "Assigned Approver",
    dueDate: "Due Date",
    itemStatus: "Item Status",
    itemRevisionNumber: "Item Revision Number",
    authorityValidationResult: "Authority-validation result",
    findEligibleApprover: "Find Eligible Approver",
    eligibleAuthorities: "Eligible Authorities",
    restrictionsNotes: "Restrictions/Notes",
    saveItem: "Save Item",
    cancelItem: "Cancel",
    confirmRemoveItem: "Are you sure you want to remove this item?",
    confirmDiscardChanges: "You have unsaved changes. Discard them?",
    yes: "Yes",
    no: "No",
    close: "Close",
    openReferral: "Open Referral",
    returnToMyReferrals: "Return to My Referrals",
    referralSubmitted: "Referral submitted successfully",
    validationBlocking: "Blocking Error",
    validationWarning: "Warning",
    validationTBC: "TBC/Configuration",
    focus: "Focus",
    permissionDenied: "Permission Denied",
    inaccessibleRecord: "Record inaccessible or not found.",
    unexpectedError: "Unexpected error occurred.",
    expiringSoon: "Expiring soon",
    eligibleAuthority: "Eligible Authority",
    selectOpportunity: "Select Opportunity",
    select: "Select",
    loadingOpportunities: "Loading opportunities...",
    loadingReferral: "Loading referral...",
    loadingItems: "Loading items...",
    loadingAuthorities: "Loading eligible authorities...",
    noEligibleAuthority: "No eligible authority found.",
    duplicateReasonCover: "Duplicate Reason + Cover/Section not allowed.",
    requiredFieldsMissing: "Please complete all required fields.",
    authorityAssignmentRequired: "Select an eligible authority assignment.",
    saveSuccess: "Saved successfully.",
    saveFailed: "Save failed.",
    submitFailed: "Submission failed.",
    busy: "Processing...",
    noOpportunitiesFound: "No opportunities found.",
    // Add more as needed
  },
};

// --- Styles ---
const useStyles = makeStyles({
  root: {
    flexGrow: 1,
    alignSelf: "stretch",
    width: "100%",
    height: "100%",
    boxSizing: "border-box",
    display: "flex",
    flexDirection: "column",
    backgroundColor: tokens.colorNeutralBackground1,
  },
  header: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    minHeight: "56px",
    padding: tokens.spacingHorizontalL,
    borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    backgroundColor: tokens.colorNeutralBackground2,
    boxSizing: "border-box",
    zIndex: 2,
  },
  headerLeft: {
    display: "flex",
    alignItems: "center",
    gap: tokens.spacingHorizontalM,
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
    gap: tokens.spacingHorizontalM,
  },
  statusTag: {
    marginInlineStart: tokens.spacingHorizontalM,
  },
  progress: {
    padding: tokens.spacingVerticalS,
    backgroundColor: tokens.colorNeutralBackground2,
    borderBottom: `1px solid ${tokens.colorNeutralStroke1}`,
    zIndex: 1,
  },
  validationSummary: {
    padding: tokens.spacingVerticalS,
    backgroundColor: tokens.colorStatusWarningBackground3,
    borderBottom: `1px solid ${tokens.colorStatusWarningBorder2}`,
    zIndex: 1,
  },
  pageBody: {
    flex: 1,
    overflowY: "auto",
    padding: tokens.spacingHorizontalL,
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalL,
    minHeight: 0,
    boxSizing: "border-box",
  },
  footer: {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    gap: tokens.spacingHorizontalM,
    padding: tokens.spacingVerticalS,
    borderTop: `1px solid ${tokens.colorNeutralStroke1}`,
    backgroundColor: tokens.colorNeutralBackground2,
    boxSizing: "border-box",
    minHeight: "56px",
    zIndex: 2,
  },
  busyOverlay: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    background: "rgba(255,255,255,0.6)",
    zIndex: 1000,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  dialog: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    background: "rgba(0,0,0,0.2)",
    zIndex: 2000,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  drawer: {
    position: "fixed",
    top: 0,
    right: 0,
    width: "100%",
    maxWidth: "480px",
    height: "100vh",
    background: tokens.colorNeutralBackground1,
    boxShadow: tokens.shadow16,
    zIndex: 2100,
    display: "flex",
    flexDirection: "column",
    overflowY: "auto",
    transition: "transform 0.3s",
  },
  // Responsive
  wideLayout: {
    flexDirection: "row",
    gap: tokens.spacingHorizontalL,
  },
  leftRegion: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalL,
  },
  rightRegion: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column",
    gap: tokens.spacingVerticalL,
  },
});

// --- Main Component ---
const GeneratedComponent: React.FC<any> = (props) => {
  // Localization
  const language = useMemo(() => {
    const uiLanguageId =
      (typeof Xrm !== "undefined" &&
        Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
      1033;
    return langMap[uiLanguageId]?.code || "en-US";
  }, []);
  const t = (key: string): string =>
    translations[language]?.[key] || translations["en-US"]?.[key] || key;
  const isRTL = useMemo(() => {
    const uiLanguageId =
      (typeof Xrm !== "undefined" &&
        Xrm.Utility?.getGlobalContext()?.userSettings?.languageId) ||
      1033;
    return langMap[uiLanguageId]?.isRtl || false;
  }, []);

  // User Settings for Formatting (date, number, currency)
  const [userSettings, setUserSettings] = useState<any>(null);
  useEffect(() => {
    const fetchUserSettings = async () => {
      const currentUserId =
        (typeof Xrm !== "undefined" &&
          Xrm.Utility?.getGlobalContext()?.userSettings?.userId)
          ?.replace("{", "")
          .replace("}", "");
      if (!currentUserId || !props.dataApi) return;
      const settings = await props.dataApi.retrieveRow("usersettings", {
        id: currentUserId,
        select: [
          "uilanguageid",
          "localeid",
          "decimalsymbol",
          "numberseparator",
          "currencysymbol",
          "dateformatstring",
          "dateseparator",
        ],
      });
      setUserSettings(settings);
    };
    fetchUserSettings();
  }, [props.dataApi]);
  // Formatting helpers
  const formatDate = (date: Date | string | number | null | undefined): string => {
    if (date === null || date === undefined || date === "") return "";
    const d = date instanceof Date ? date : new Date(date);
    if (isNaN(d.getTime())) return "";
    if (!userSettings) return d.toLocaleDateString(language);
    const sep = userSettings.dateseparator || "/";
    const fmt = (userSettings.dateformatstring || "MM/dd/yyyy")
      .replace("yyyy", d.getFullYear().toString())
      .replace("MM", String(d.getMonth() + 1).padStart(2, "0"))
      .replace("dd", String(d.getDate()).padStart(2, "0"))
      .replace("/", sep)
      .replace("/", sep);
    return fmt;
  };
  const formatNumber = (value: number | string | null | undefined): string => {
    if (value === null || value === undefined || value === "") return "";
    const num = typeof value === "number" ? value : Number(value);
    if (isNaN(num)) return "";
    if (!userSettings) return new Intl.NumberFormat(language).format(num);
    const dec = userSettings.decimalsymbol || ".";
    const grp = userSettings.numberseparator || ",";
    const parts = num.toFixed(2).split(".");
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, grp);
    return parts.join(dec);
  };
  const formatCurrency = (value: number | string | null | undefined): string => {
    if (value === null || value === undefined || value === "") return "";
    const symbol = userSettings?.currencysymbol || "$";
    return `${symbol}${formatNumber(value)}`;
  };

  // --- State Variables ---
  const styles = useStyles();
  const [varMode, setVarMode] = useState<"Create" | "Opportunity" | "Referral" | "Invalid">("Create");
  const [varStep, setVarStep] = useState<number>(1);
  const [varReferral, setVarReferral] = useState<any>(null);
  const [varOpportunity, setVarOpportunity] = useState<any>(null);
  const [varReferralItems, setVarReferralItems] = useState<any[]>([]);
  const [varEditingItem, setVarEditingItem] = useState<any>(null);
  const [varIsNewItem, setVarIsNewItem] = useState<boolean>(false);
  const [varBusy, setVarBusy] = useState<boolean>(false);
  const [varDirty, setVarDirty] = useState<boolean>(false);
  const [colValidationErrors, setColValidationErrors] = useState<any[]>([]);
  const [colEligibleAuthorities, setColEligibleAuthorities] = useState<any[]>([]);
  const [dlgDiscardChanges, setDlgDiscardChanges] = useState<boolean>(false);
  const [dlgRemoveItem, setDlgRemoveItem] = useState<{ open: boolean; item: any }>({ open: false, item: null });
  const [dlgItemEditor, setDlgItemEditor] = useState<boolean>(false);
  const [pageError, setPageError] = useState<string | null>(null);
  const [opportunities, setOpportunities] = useState<any[]>([]);
  const [opportunityLoading, setOpportunityLoading] = useState<boolean>(false);
  const [referralLoading, setReferralLoading] = useState<boolean>(false);
  const [itemsLoading, setItemsLoading] = useState<boolean>(false);

  // --- Entry Mode Detection ---
  useEffect(() => {
    // Detect entry mode based on pageInput
    const { pageInput } = props;
    if (pageInput?.entityName === "opportunity" && pageInput?.recordId) {
      setVarMode("Opportunity");
      setVarStep(1);
      // Load opportunity
      loadOpportunity(pageInput.recordId);
    } else if (pageInput?.entityName === "slcrm_referralrequest" && pageInput?.recordId) {
      setVarMode("Referral");
      setVarStep(1);
      // Load referral
      loadReferral(pageInput.recordId);
    } else {
      setVarMode("Create");
      setVarStep(1);
      // No context, show opportunity selector
    }
    // eslint-disable-next-line
  }, [props.pageInput]);

  // --- Load Opportunity ---
  const loadOpportunity = async (opportunityId: string) => {
    if (!props.dataApi) return;
    setOpportunityLoading(true);
    try {
      const opp = await props.dataApi.retrieveRow("opportunity", {
        id: opportunityId,
        select: [
          "opportunityid",
          "name",
          "slcrm_opportunitynumber",
          "customerid",
          "slcrm_product",
          "slcrm_primaryunderwriter",
          "statecode",
          "statuscode",
        ],
        expand: {
          customerid: { select: ["name"] },
          slcrm_product: { select: ["slcrm_productid", "slcrm_name", "slcrm_isleaf"] },
          slcrm_primaryunderwriter: { select: ["systemuserid", "fullname"] },
        },
      });
      setVarOpportunity(opp);
    } catch (err) {
      setPageError(t("inaccessibleRecord"));
    }
    setOpportunityLoading(false);
  };

  // --- Load Referral ---
  const loadReferral = async (referralId: string) => {
    if (!props.dataApi) return;
    setReferralLoading(true);
    try {
      const referral = await props.dataApi.retrieveRow("slcrm_referralrequest", {
        id: referralId,
        select: [
          "slcrm_referralrequestid",
          "slcrm_referralnumber",
          "slcrm_opportunity",
          "slcrm_product",
          "slcrm_customer",
          "slcrm_primaryunderwriter",
          "statuscode",
        ],
        expand: {
          slcrm_opportunity: { select: ["name", "slcrm_opportunitynumber"] },
          slcrm_product: { select: ["slcrm_productid", "slcrm_name"] },
          slcrm_customer: { select: ["accountid", "name"] },
          slcrm_primaryunderwriter: { select: ["systemuserid", "fullname"] },
        },
      });
      setVarReferral(referral);
      setVarOpportunity(referral.slcrm_opportunity);
      // Load items
      loadReferralItems(referralId);
    } catch (err) {
      setPageError(t("inaccessibleRecord"));
    }
    setReferralLoading(false);
  };

  // --- Load Referral Items ---
  const loadReferralItems = async (referralId: string) => {
    if (!props.dataApi) return;
    setItemsLoading(true);
    try {
      const result = await props.dataApi.queryTable("slcrm_referralitem", {
        select: [
          "slcrm_referralitemid",
          "slcrm_referralitemnumber",
          "slcrm_referralreason",
          "slcrm_coversection",
          "slcrm_itemsummary",
          "slcrm_requiredauthoritylevel",
          "slcrm_selectedapprover",
          "statuscode",
          "slcrm_duedate",
        ],
        filter: `slcrm_referral eq ${referralId}`,
        orderBy: "slcrm_referralitemnumber asc",
        expand: {
          slcrm_referralreason: { select: ["slcrm_name"] },
          slcrm_coversection: { select: ["slcrm_name"] },
          slcrm_selectedapprover: { select: ["fullname"] },
        },
      });
      setVarReferralItems(result.rows);
    } catch (err) {
      setPageError(t("unexpectedError"));
    }
    setItemsLoading(false);
  };

  // --- Load Opportunities for Selector ---
  useEffect(() => {
    if (varMode === "Create" && props.dataApi) {
      setOpportunityLoading(true);
      props.dataApi
        .queryTable("opportunity", {
          select: [
            "opportunityid",
            "name",
            "slcrm_opportunitynumber",
            "customerid",
            "slcrm_product",
            "slcrm_primaryunderwriter",
            "statecode",
            "statuscode",
          ],
          filter: "statecode eq 0", // Active
          orderBy: "createdon desc",
          top: 50,
          expand: {
            customerid: { select: ["name"] },
            slcrm_product: { select: ["slcrm_productid", "slcrm_name", "slcrm_isleaf"] },
            slcrm_primaryunderwriter: { select: ["systemuserid", "fullname"] },
          },
        })
        .then((result: any) => {
          setOpportunities(result.rows);
        })
        .catch(() => setOpportunities([]))
        .finally(() => setOpportunityLoading(false));
    }
    // eslint-disable-next-line
  }, [varMode, props.dataApi]);

  // --- Responsive Layout ---
  const [isWide, setIsWide] = useState<boolean>(window.innerWidth > 900);
  useEffect(() => {
    const handleResize = () => setIsWide(window.innerWidth > 900);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // --- Step Navigation ---
  const canGoToStep2 = !!varReferral;
  const canGoToStep3 = varReferralItems.length > 0;

  // --- Validation ---
  const validateParent = () => {
    const errors: any[] = [];
    if (!varOpportunity) {
      errors.push({
        scope: "Parent",
        field: "Opportunity",
        message: t("required"),
        severity: "error",
      });
    }
    // ... add more field validations as needed
    setColValidationErrors(errors);
    return errors.length === 0;
  };

  // --- Save and Continue ---
  const handleSaveAndContinue = async () => {
    if (!validateParent()) {
      setVarStep(1);
      return;
    }
    setVarBusy(true);
    try {
      // Create parent Referral
      const parentPayload = {
        slcrm_opportunity: varOpportunity.opportunityid,
        // ... map other fields as needed
        statuscode: 1, // Draft
      };
      const created = await props.dataApi.createRow("slcrm_referralrequest", parentPayload);
      setVarReferral(created);
      setVarDirty(false);
      setVarStep(2);
      // Load items (should be empty)
      loadReferralItems(created.slcrm_referralrequestid);
    } catch (err) {
      setPageError(t("saveFailed"));
    }
    setVarBusy(false);
  };

  // --- Save Draft ---
  const handleSaveDraft = async () => {
    setVarBusy(true);
    try {
      // Save parent and items
      // ... implement save logic
      setVarDirty(false);
      // Show success
    } catch (err) {
      setPageError(t("saveFailed"));
    }
    setVarBusy(false);
  };

  // --- Submit Referral ---
  const handleSubmitReferral = async () => {
    setVarBusy(true);
    try {
      // Call Custom API slcrm_SubmitReferral
      // ... implement API call
      setVarBusy(false);
      // On success
      setVarStep(3);
      // Show success message
    } catch (err) {
      setPageError(t("submitFailed"));
      setVarBusy(false);
    }
  };

  // --- Add/Edit Referral Item ---
  const handleAddReferralItem = () => {
    setVarEditingItem(null);
    setVarIsNewItem(true);
    setDlgItemEditor(true);
  };
  const handleEditReferralItem = (item: any) => {
    setVarEditingItem(item);
    setVarIsNewItem(false);
    setDlgItemEditor(true);
  };
  const handleRemoveReferralItem = (item: any) => {
    setDlgRemoveItem({ open: true, item });
  };

  // --- Step 1: Referral Details ---
  // Opportunity search and selection logic
  const [opportunitySearch, setOpportunitySearch] = useState<string>("");
  // For display in the Combobox, show the opportunity number and name for the selected value
  const selectedOpportunityDisplay = useMemo(() => {
    if (!varOpportunity) return "";
    const parts = [
      varOpportunity.slcrm_opportunitynumber,
      varOpportunity.name,
      varOpportunity.customerid?.name,
      varOpportunity.slcrm_product?.slcrm_name,
      varOpportunity.slcrm_primaryunderwriter?.fullname,
    ].filter(Boolean);
    return parts.join(" | ");
  }, [varOpportunity]);

  const filteredOpportunities = useMemo(() => {
    if (!opportunitySearch) return opportunities;
    const s = opportunitySearch.toLowerCase();
    return opportunities.filter((opp) =>
      [
        opp.slcrm_opportunitynumber,
        opp.name,
        opp.customerid?.name,
        opp.slcrm_product?.slcrm_name,
        opp.slcrm_primaryunderwriter?.fullname,
      ]
        .map((f) => (f || "").toLowerCase())
        .some((f) => f.includes(s))
    );
  }, [opportunities, opportunitySearch]);

  const renderReferralDetails = () => (
    <section>
      <Text as="h2" size={500} weight="semibold" block>
        {t("referralDetails")}
      </Text>
      {varMode === "Create" && (
        <div style={{ marginBottom: tokens.spacingVerticalM }}>
          <Combobox
            placeholder={t("selectOpportunity")}
            value={
              // Show the display string for the selected opportunity, or the search text if searching
              varOpportunity
                ? selectedOpportunityDisplay
                : opportunitySearch
            }
            onOptionSelect={(_, data) => {
              const opp = opportunities.find((o) => o.opportunityid === data.optionValue);
              setVarOpportunity(opp);
              setOpportunitySearch(""); // Reset search text to show selected value
              setVarDirty(true);
            }}
            onChange={(_, data) => {
              setOpportunitySearch(data.value);
              // If the user clears the input, clear the selected opportunity
              if (!data.value) setVarOpportunity(null);
            }}
            disabled={!!varReferral}
            aria-label={t("opportunity")}
            style={{ width: "100%", maxWidth: 600 }}
            // Show all options when focused
            openOnFocus
          >
            {opportunityLoading ? (
              <Option value="">{t("loadingOpportunities")}</Option>
            ) : filteredOpportunities.length === 0 ? (
              <Option value="">{t("noOpportunitiesFound")}</Option>
            ) : (
              filteredOpportunities.map((opp) => (
                <Option key={opp.opportunityid} value={opp.opportunityid}>
                  <span style={{ fontWeight: 500 }}>
                    {opp.slcrm_opportunitynumber || "-"}
                  </span>
                  {" - "}
                  {opp.name}
                  {opp.customerid?.name && (
                    <span style={{ color: tokens.colorNeutralForeground3 }}>
                      {" | " + opp.customerid.name}
                    </span>
                  )}
                  {opp.slcrm_product?.slcrm_name && (
                    <span style={{ color: tokens.colorNeutralForeground3 }}>
                      {" | " + opp.slcrm_product.slcrm_name}
                    </span>
                  )}
                  {opp.slcrm_primaryunderwriter?.fullname && (
                    <span style={{ color: tokens.colorNeutralForeground3 }}>
                      {" | " + opp.slcrm_primaryunderwriter.fullname}
                    </span>
                  )}
                  {opp.statuscode !== undefined && (
                    <span style={{ color: tokens.colorNeutralForeground3 }}>
                      {" | Stage: " + opp.statuscode}
                    </span>
                  )}
                </Option>
              ))
            )}
          </Combobox>
        </div>
      )}
      {/* Render other fields as needed */}
      <Input
        value={varOpportunity?.slcrm_product?.slcrm_name || ""}
        readOnly
        aria-label={t("product")}
        placeholder={t("product")}
        style={{ marginBottom: tokens.spacingVerticalS }}
      />
      <Input
        value={varOpportunity?.customerid?.name || ""}
        readOnly
        aria-label={t("customer")}
        placeholder={t("customer")}
        style={{ marginBottom: tokens.spacingVerticalS }}
      />
      <Input
        value={varOpportunity?.slcrm_primaryunderwriter?.fullname || ""}
        readOnly
        aria-label={t("primaryUnderwriter")}
        placeholder={t("primaryUnderwriter")}
        style={{ marginBottom: tokens.spacingVerticalS }}
      />
      {/* ... more fields as per requirements */}
      <Button
        appearance="primary"
        onClick={handleSaveAndContinue}
        disabled={varBusy || !varOpportunity}
        style={{ marginTop: tokens.spacingVerticalM }}
      >
        {t("saveAndContinue")}
      </Button>
    </section>
  );

  // --- Render Functions ---
  const renderHeader = () => (
    <header className={styles.header} dir={isRTL ? "rtl" : "ltr"}>
      <div className={styles.headerLeft}>
        <Button
          icon={<ArrowLeftRegular />}
          appearance="subtle"
          onClick={() => {
            if (varDirty) setDlgDiscardChanges(true);
            else window.history.back();
          }}
          aria-label={t("back")}
        />
        <Text as="h1" size={600} weight="semibold">
          {t("createReferral")}
        </Text>
        <Text size={400} style={{ marginInlineStart: tokens.spacingHorizontalM }}>
          {varReferral?.slcrm_referralnumber || t("newReferral")}
        </Text>
        {varReferral && (
          <Tag
            shape="circular"
            appearance="brand"
            className={styles.statusTag}
            aria-label={t("status")}
          >
            {varReferral.statuscode}
          </Tag>
        )}
      </div>
      <div className={styles.headerRight}>
        <Button
          icon={<SaveRegular />}
          appearance="primary"
          onClick={handleSaveDraft}
          disabled={varBusy}
        >
          {t("saveDraft")}
        </Button>
        <Button
          icon={<DismissRegular />}
          appearance="secondary"
          onClick={() => {
            if (varDirty) setDlgDiscardChanges(true);
            else window.history.back();
          }}
        >
          {t("cancel")}
        </Button>
      </div>
    </header>
  );

  const renderProgress = () => (
    <div className={styles.progress}>
      <ProgressBar
        value={varStep / 3}
        thickness="large"
        shape="rounded"
        style={{ width: "100%" }}
        aria-valuenow={varStep}
        aria-valuemin={1}
        aria-valuemax={3}
        aria-label={t("progress")}
      />
      <div style={{ display: "flex", gap: tokens.spacingHorizontalL, marginTop: tokens.spacingVerticalXS }}>
        <Button
          appearance={varStep === 1 ? "primary" : "subtle"}
          onClick={() => setVarStep(1)}
          disabled={varStep < 1}
        >
          {t("referralDetails")}
        </Button>
        <Button
          appearance={varStep === 2 ? "primary" : "subtle"}
          onClick={() => canGoToStep2 && setVarStep(2)}
          disabled={!canGoToStep2}
        >
          {t("referralItems")}
        </Button>
        <Button
          appearance={varStep === 3 ? "primary" : "subtle"}
          onClick={() => canGoToStep3 && setVarStep(3)}
          disabled={!canGoToStep3}
        >
          {t("reviewAndSubmit")}
        </Button>
      </div>
    </div>
  );

  const renderValidationSummary = () =>
    colValidationErrors.length > 0 && (
      <div className={styles.validationSummary} role="alert">
        <Text size={400} weight="semibold" block>
          {t("validationSummary")}
        </Text>
        <ul>
          {colValidationErrors.map((err, idx) => (
            <li key={idx}>
              <InfoRegular
                fontSize="16px"
                color={err.severity === "error" ? tokens.colorStatusDangerForeground1 : tokens.colorStatusWarningForeground1}
                aria-label={err.severity === "error" ? t("validationBlocking") : t("validationWarning")}
              />
              <span style={{ marginInlineStart: 8 }}>
                {err.scope}: {err.field} - {err.message}
              </span>
              <Button
                appearance="subtle"
                size="small"
                onClick={() => {
                  if (err.scope === "Parent") setVarStep(1);
                  else if (err.scope === "Item") setVarStep(2);
                }}
                style={{ marginInlineStart: 8 }}
              >
                {t("focus")}
              </Button>
            </li>
          ))}
        </ul>
      </div>
    );

  // --- Step 2: Referral Items ---
  const renderReferralItems = () => (
    <section>
      <Text as="h2" size={500} weight="semibold" block>
        {t("referralItems")}
      </Text>
      <Button
        icon={<AddRegular />}
        appearance="primary"
        onClick={handleAddReferralItem}
        disabled={varBusy || !varReferral}
        style={{ marginBottom: tokens.spacingVerticalS }}
      >
        {t("addReferralItem")}
      </Button>
      <div style={{ maxHeight: "calc(100vh - 340px)", overflow: "auto" }}>
        {itemsLoading ? (
          <Text>{t("loadingItems")}</Text>
        ) : varReferralItems.length === 0 ? (
          <Text>{t("noReferralItems")}</Text>
        ) : (
          <DataGrid
            items={varReferralItems}
            columns={[
              createTableColumn({
                columnId: "slcrm_referralitemnumber",
                renderHeaderCell: () => t("referralNumber"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_referralitemnumber}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_referralreason",
                renderHeaderCell: () => t("referralReason"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_referralreason?.slcrm_name}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_coversection",
                renderHeaderCell: () => t("coverSection"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_coversection?.slcrm_name}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_itemsummary",
                renderHeaderCell: () => t("itemSummary"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_itemsummary}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_requiredauthoritylevel",
                renderHeaderCell: () => t("requiredAuthorityLevel"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_requiredauthoritylevel}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_selectedapprover",
                renderHeaderCell: () => t("assignedApprover"),
                renderCell: (item) => <TableCellLayout>{item.slcrm_selectedapprover?.fullname}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "statuscode",
                renderHeaderCell: () => t("status"),
                renderCell: (item) => <TableCellLayout>{item.statuscode}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "slcrm_duedate",
                renderHeaderCell: () => t("dueDate"),
                renderCell: (item) => <TableCellLayout>{formatDate(item.slcrm_duedate)}</TableCellLayout>,
              }),
              createTableColumn({
                columnId: "actions",
                renderHeaderCell: () => "",
                renderCell: (item) => (
                  <div style={{ display: "flex", gap: 8 }}>
                    <Button
                      icon={<EditRegular />}
                      appearance="subtle"
                      size="small"
                      onClick={() => handleEditReferralItem(item)}
                      aria-label={t("edit")}
                    />
                    <Button
                      icon={<DeleteRegular />}
                      appearance="subtle"
                      size="small"
                      onClick={() => handleRemoveReferralItem(item)}
                      aria-label={t("remove")}
                    />
                  </div>
                ),
              }),
            ]}
            selectionMode="none"
            getRowId={(item) => item.slcrm_referralitemid}
            focusMode="composite"
          >
            <DataGridHeader>
              <DataGridRow>
                {({ renderHeaderCell }) => (
                  <DataGridHeaderCell>{renderHeaderCell()}</DataGridHeaderCell>
                )}
              </DataGridRow>
            </DataGridHeader>
            <DataGridBody>
              {({ item }) => (
                <DataGridRow key={item.slcrm_referralitemid}>
                  {({ renderCell }) => <DataGridCell>{renderCell(item)}</DataGridCell>}
                </DataGridRow>
              )}
            </DataGridBody>
          </DataGrid>
        )}
      </div>
    </section>
  );

  // --- Step 3: Review and Submit ---
  const renderReviewAndSubmit = () => (
    <section>
      <Text as="h2" size={500} weight="semibold" block>
        {t("reviewAndSubmit")}
      </Text>
      {/* Parent summary */}
      <div style={{ marginBottom: tokens.spacingVerticalM }}>
        <Text size={400} weight="semibold" block>
          {t("referralNumber")}: {varReferral?.slcrm_referralnumber || t("newReferral")}
        </Text>
        <Text>{t("opportunity")}: {varOpportunity?.name}</Text>
        <Text>{t("product")}: {varOpportunity?.slcrm_product?.slcrm_name}</Text>
        <Text>{t("customer")}: {varOpportunity?.customerid?.name}</Text>
        <Text>{t("primaryUnderwriter")}: {varOpportunity?.slcrm_primaryunderwriter?.fullname}</Text>
        {/* ... more fields as needed */}
      </div>
      {/* Item summary */}
      <div>
        <Text size={400} weight="semibold" block>
          {t("referralItems")}
        </Text>
        {varReferralItems.map((item, idx) => (
          <div
            key={item.slcrm_referralitemid}
            style={{
              border: `1px solid ${tokens.colorNeutralStroke1}`,
              borderRadius: tokens.borderRadiusMedium,
              padding: tokens.spacingVerticalS,
              marginBottom: tokens.spacingVerticalS,
            }}
          >
            <Text>
              {t("referralReason")}: {item.slcrm_referralreason?.slcrm_name}
            </Text>
            <Text>
              {t("coverSection")}: {item.slcrm_coversection?.slcrm_name}
            </Text>
            <Text>
              {t("itemSummary")}: {item.slcrm_itemsummary}
            </Text>
            <Text>
              {t("requiredAuthorityLevel")}: {item.slcrm_requiredauthoritylevel}
            </Text>
            <Text>
              {t("assignedApprover")}: {item.slcrm_selectedapprover?.fullname}
            </Text>
            {/* ... more fields as needed */}
          </div>
        ))}
      </div>
      {/* Validation summary */}
      {renderValidationSummary()}
      {/* Submit button */}
      <Button
        appearance="primary"
        onClick={handleSubmitReferral}
        disabled={varBusy || !varReferral || varReferralItems.length === 0}
        style={{ marginTop: tokens.spacingVerticalM }}
      >
        {t("submitReferral")}
      </Button>
    </section>
  );

  // --- Main Render ---
  return (
    <div
      className={styles.root}
      dir={isRTL ? "rtl" : "ltr"}
      style={{ direction: isRTL ? "rtl" : "ltr" }}
    >
      {renderHeader()}
      {renderProgress()}
      {renderValidationSummary()}
      <main
        className={styles.pageBody}
        style={
          isWide
            ? { flexDirection: "row", gap: tokens.spacingHorizontalL }
            : { flexDirection: "column" }
        }
      >
        {isWide ? (
          <>
            <div className={styles.leftRegion}>
              {varStep === 1 && renderReferralDetails()}
              {varStep === 3 && renderReviewAndSubmit()}
            </div>
            <div className={styles.rightRegion}>
              {varStep === 2 && renderReferralItems()}
            </div>
          </>
        ) : (
          <>
            {varStep === 1 && renderReferralDetails()}
            {varStep === 2 && renderReferralItems()}
            {varStep === 3 && renderReviewAndSubmit()}
          </>
        )}
      </main>
      {/* Footer */}
      <footer className={styles.footer}>
        {/* Add footer commands as needed */}
      </footer>
      {/* Busy Overlay */}
      {varBusy && (
        <div className={styles.busyOverlay} aria-busy="true">
          <Text size={500}>{t("busy")}</Text>
        </div>
      )}
      {/* Discard Changes Dialog */}
      {dlgDiscardChanges && (
        <div className={styles.dialog} role="dialog" aria-modal="true">
          <div
            style={{
              background: tokens.colorNeutralBackground1,
              padding: tokens.spacingVerticalL,
              borderRadius: tokens.borderRadiusMedium,
              minWidth: 320,
              maxWidth: 400,
              boxShadow: tokens.shadow16,
              display: "flex",
              flexDirection: "column",
              gap: tokens.spacingVerticalM,
            }}
          >
            <Text size={400} weight="semibold">
              {t("confirmDiscardChanges")}
            </Text>
            <div style={{ display: "flex", gap: tokens.spacingHorizontalM, justifyContent: "flex-end" }}>
              <Button
                appearance="primary"
                onClick={() => {
                  setDlgDiscardChanges(false);
                  setVarDirty(false);
                  window.history.back();
                }}
              >
                {t("yes")}
              </Button>
              <Button appearance="secondary" onClick={() => setDlgDiscardChanges(false)}>
                {t("no")}
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Remove Item Dialog */}
      {dlgRemoveItem.open && (
        <div className={styles.dialog} role="dialog" aria-modal="true">
          <div
            style={{
              background: tokens.colorNeutralBackground1,
              padding: tokens.spacingVerticalL,
              borderRadius: tokens.borderRadiusMedium,
              minWidth: 320,
              maxWidth: 400,
              boxShadow: tokens.shadow16,
              display: "flex",
              flexDirection: "column",
              gap: tokens.spacingVerticalM,
            }}
          >
            <Text size={400} weight="semibold">
              {t("confirmRemoveItem")}
            </Text>
            <div style={{ display: "flex", gap: tokens.spacingHorizontalM, justifyContent: "flex-end" }}>
              <Button
                appearance="primary"
                onClick={() => {
                  // Remove item logic
                  setDlgRemoveItem({ open: false, item: null });
                }}
              >
                {t("yes")}
              </Button>
              <Button appearance="secondary" onClick={() => setDlgRemoveItem({ open: false, item: null })}>
                {t("no")}
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* Item Editor Drawer */}
      {dlgItemEditor && (
        <div className={styles.drawer} role="dialog" aria-modal="true">
          {/* Implement Add/Edit Referral Item form here */}
          <Text size={500} weight="semibold" block style={{ margin: tokens.spacingVerticalM }}>
            {varIsNewItem ? t("addReferralItem") : t("edit")}
          </Text>
          {/* ... item editor fields */}
          <div style={{ display: "flex", gap: tokens.spacingHorizontalM, justifyContent: "flex-end", margin: tokens.spacingVerticalM }}>
            <Button appearance="primary" onClick={() => setDlgItemEditor(false)}>
              {t("saveItem")}
            </Button>
            <Button appearance="secondary" onClick={() => setDlgItemEditor(false)}>
              {t("cancelItem")}
            </Button>
          </div>
        </div>
      )}
      {/* Page Error */}
      {pageError && (
        <div className={styles.dialog} role="alertdialog" aria-modal="true">
          <div
            style={{
              background: tokens.colorNeutralBackground1,
              padding: tokens.spacingVerticalL,
              borderRadius: tokens.borderRadiusMedium,
              minWidth: 320,
              maxWidth: 400,
              boxShadow: tokens.shadow16,
              display: "flex",
              flexDirection: "column",
              gap: tokens.spacingVerticalM,
            }}
          >
            <Text size={400} weight="semibold">
              {t("error")}
            </Text>
            <Text>{pageError}</Text>
            <Button appearance="primary" onClick={() => setPageError(null)}>
              {t("close")}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneratedComponent;